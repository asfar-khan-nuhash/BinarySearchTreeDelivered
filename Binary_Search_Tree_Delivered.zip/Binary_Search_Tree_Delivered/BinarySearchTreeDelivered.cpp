#include "BinarySearchTreeDelivered.hpp"

void clrInputBuffer() {
    while (std::cin.get() != '\n') {
        continue;
    }
} //Because input buffer may contain newlines that use up cin and skip user input

int main(){

    int ID;
    string name, address;
    double fee;

    deliverySearchTree delivery ("This Delivery");

    //Main Menu of program
    string option;
    bool endprogram;
    bool back;

    while(!endprogram){
        back = false;
        cout<<"\n--D E L I V E R Y   S Y S T E M--"<<endl<<endl;
        cout<<"1. Add Deliveries to deliver"<<endl;
        cout<<"2. View Deliveries in with different sorting"<<endl;
        cout<<"0. Exit Program"<<endl;
        cout<<"Option: ";
        getline(cin, option);


        switch (option[0]) {
            case '1':
                system("cls");
                cout << "\nA D D   D E L I V E R I E S"<<endl;
                cout << "\nEnter Item ID: ";
                cin >> ID;
                clrInputBuffer();
                cout << "\nEnter Item Name: ";
                getline(cin, name);
                cout << "\nEnter Item address: ";
                getline(cin, address);
                cout << "\nEnter delivery fee: ";
                cin >> fee;
                clrInputBuffer();

                delivery.inputDelivery(ID, name, address, fee);

                break;
            case '2':
                system("cls");
                cout << "\nV I E W   D E L I V E R I E S"<<endl;
                while(!back){
                    back = false;

                    cout<<endl<<endl;
                    cout<<"1. Level Order Traversal"<<endl;
                    cout<<"2. Preorder"<<endl;
                    cout<<"3. Inorder"<<endl;
                    cout<<"4. Postorder"<<endl;
                    cout<<"0. GO BACK"<<endl;
                    cout<<"Option: ";
                    getline(cin, option);

                    switch (option[0]){
                        case '1':
                            system("cls");
                            
                            cout<<"\n- LEVEL ORDER TRAVERSAL -"<<endl<<endl;
                            cout << left << setw(20) << "Delivery ID" << left << setw(20) <<  "Delivery Name" << left << setw(20) << "Delivery address" << left << setw(20) << "Delivery Fee" <<endl;
                            cout << "---------------------------------------------------------------------------" << endl;
                            delivery.call_levelorder();
                            cout<<endl<<endl;
                            cout<< "Total Delivery Fee: " << delivery.call_totalDeliveryFee() << endl<< endl;
                            system("pause");

                            break;
                        case '2':
                            system("cls");

                            cout<<"\n- PREORDER TRAVERSAL -"<<endl<<endl;
                            cout << left << setw(20) << "Delivery ID" << left << setw(20) <<  "Delivery Name" << left << setw(20) << "Delivery address" << left << setw(20) << "Delivery Fee" <<endl;
                            cout << "---------------------------------------------------------------------------" << endl;
                            delivery.call_preorder();
                            cout<<endl<<endl;
                            cout<< "Total Delivery Fee: " << delivery.call_totalDeliveryFee() << endl<< endl;
                            system("pause");

                            break;
                        case '3':
                            system("cls");

                            cout<<"\n- INORDER TRAVERSAL -"<<endl<<endl;
                            cout << left << setw(20) << "Delivery ID" << left << setw(20) <<  "Delivery Name" << left << setw(20) << "Delivery address" << left << setw(20) << "Delivery Fee" <<endl;
                            cout << "---------------------------------------------------------------------------" << endl;
                            delivery.call_inorder();
                            cout<<endl<<endl;
                            cout<< "Total Delivery Fee: " << delivery.call_totalDeliveryFee() << endl<< endl;
                            system("pause");

                            break;

                        case '4':
                            system("cls");

                            cout<<"\n- POSTORDER TRAVERSAL -"<<endl<<endl;
                            cout << left << setw(20) << "Delivery ID" << left << setw(20) <<  "Delivery Name" << left << setw(20) << "Delivery address" << left << setw(20) << "Delivery Fee" <<endl;
                            cout << "---------------------------------------------------------------------------" << endl;
                            delivery.call_postorder();
                            cout<<endl<<endl;
                            cout<< "Total Delivery Fee: " << delivery.call_totalDeliveryFee() << endl<< endl;
                            system("pause");

                            break;

                        case '0':
                            system("cls");
                            back = true;
                            break;
                        default:
                            system("cls");
                            
                            cout<<"\nINVALID OPTION"<<endl;
                    }
                }
                break;
            case '0':
                system("cls");
                cout << "\nEXITING PROGRAM\n";
                endprogram = true;
                break;
            default:
                system("cls");
                cout << "Invalid choice. Please try again.\n";
                break;
        }

        
    }

    return 0;
}