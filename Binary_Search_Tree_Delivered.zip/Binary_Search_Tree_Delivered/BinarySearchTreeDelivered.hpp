#include <bits/stdc++.h>
using namespace std;

//Creating Delivered Structure

struct deliverynode{
    int delivery_id;
    string delivery_name;
    string delivery_address;
    double delivery_fee;
    deliverynode* left;
    deliverynode* right;
};

class deliverySearchTree{
	deliverynode* root;
	string name;

public:
    deliverySearchTree(string name){ // CONSTRUCTOR
        root = nullptr;
        this->name = name;
    }

    void inputDelivery(int ID, string name, string address, double fee){
        //CREATE A NODE
        deliverynode* newnode = new deliverynode;
		newnode->delivery_id = ID;
        newnode->delivery_name = name;
        newnode->delivery_address = address;
        newnode->delivery_fee = fee;
		newnode->left = nullptr;
		newnode->right = nullptr;

        //Insert Root of node (this is the pointer, it holds the memory address of this node)
        if (root == nullptr){
			root = newnode;
			return;
		}

        deliverynode* parentnode = nullptr; 
		deliverynode* current = root;

		while (current != nullptr){
			if (current->delivery_id == ID){
				cout << ID << " already exists." << endl;
				return;
			}
			parentnode = current;
            //Bigger value to the right
			if (ID > current->delivery_id){
				current = current->right;
			}
            //Smaller value to the left
			else{
				current = current->left;
			}
		}

        if (ID > parentnode->delivery_id){
			parentnode->right = newnode;
		}
		else{
			parentnode->left = newnode;
		}

    }

    // Display Methods: these will be used to print out the deliveries with the new orders

    void call_preorder(){
		preorder(root);
	}
	void call_inorder(){
		inorder(root);
	}
	void call_postorder(){
		postorder(root);
	}

    void call_levelorder(){
        int height = getHeight(root);
        for (int i = 1; i <= height; i++){
            printLevel(root, i);
        }
    }
    
    int return_Height()
	{
		return getHeight(root);
	}

    int call_totalDeliveryFee()
	{
		return totalDeliveryFee(root);
	}

private:
    void preorder(deliverynode* parentnode){
		if (parentnode != nullptr){
			cout << left << setw(20) << parentnode->delivery_id << left << setw(20)<< parentnode->delivery_name << left << setw(20) << parentnode->delivery_address << left << setw(20) << parentnode->delivery_fee <<endl;
			preorder(parentnode->left); 
			preorder(parentnode->right); 
		}
	}
	void inorder(deliverynode* parentnode){
		if (parentnode != nullptr){
			inorder(parentnode->left); 
			cout << left << setw(20) << parentnode->delivery_id << left << setw(20)<< parentnode->delivery_name << left << setw(20) << parentnode->delivery_address << left << setw(20) << parentnode->delivery_fee <<endl;
			inorder(parentnode->right); 
		}
	}
	void postorder(deliverynode* parentnode){
		if (parentnode != nullptr){
			postorder(parentnode->left); 
			postorder(parentnode->right); 
			cout << left << setw(20) << parentnode->delivery_id << left << setw(20)<< parentnode->delivery_name << left << setw(20) << parentnode->delivery_address << left << setw(20) << parentnode->delivery_fee <<endl;
		}
	}

    int getHeight(deliverynode* parentnode)
	{
		if (parentnode == nullptr)
			return 0;

		return 1 + max(getHeight(parentnode->left), getHeight(parentnode->right));
	}

    void printLevel(deliverynode* parentnode, int level){
        if (parentnode == nullptr){
            return;
        }
        if (level == 1){
            cout << left << setw(20) << parentnode->delivery_id << left << setw(20)<< parentnode->delivery_name << left << setw(20) << parentnode->delivery_address << left << setw(20) << parentnode->delivery_fee <<endl;
        }
        else if (level > 1){
            printLevel(parentnode->left, level - 1);
            printLevel(parentnode->right, level - 1);
        }
    }

    int totalDeliveryFee(deliverynode* parentnode){
		if (parentnode == nullptr)
			return 0;

		return parentnode->delivery_fee + totalDeliveryFee(parentnode->left) + totalDeliveryFee(parentnode->right);
	}

};